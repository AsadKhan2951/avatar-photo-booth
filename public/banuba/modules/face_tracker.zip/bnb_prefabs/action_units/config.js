'use strict';

const prefabs = require("bnb_js/prefabs");

class ActionUnits extends prefabs.Base {
    constructor() {
        super()
    }

    clear() {

    }
}

exports = {
    ActionUnits
}