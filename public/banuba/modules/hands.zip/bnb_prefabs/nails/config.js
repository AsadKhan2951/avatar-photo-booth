'use strict';

const prefabs = require("bnb_js/prefabs");

const defaultGloss = 40;

class Nails extends prefabs.Base {
    constructor() {
        super();

        const assets = bnb.scene.getAssetManager();

        this._nailsMaterial1 = this._getMaterial('shaders/nails/nail1');
        this._nailsMaterial2 = this._getMaterial('shaders/nails/nail2');
        this._nailsMaterial3 = this._getMaterial('shaders/nails/nail3');
        this._nailsMaterial4 = this._getMaterial('shaders/nails/nail4');
        this._nailsMaterial5 = this._getMaterial('shaders/nails/nail5');


        this._textures = [
            assets.findImage("nail1_texture")?.asTexture(),
            assets.findImage("nail2_texture")?.asTexture(),
            assets.findImage("nail3_texture")?.asTexture(),
            assets.findImage("nail4_texture")?.asTexture(),
            assets.findImage("nail5_texture")?.asTexture(),
        ];

        this._color = new bnb.FeatureParameter(0, 0, 0, 0);
        this._gloss = new bnb.FeatureParameter(defaultGloss, 0, 0, 0);
        this._entity = bnb.scene.getRoot().findChildByName("nails_tracker");
    }

    color(color) {
        const vecColor = prefabs.parseColor(color);
        this._color = new bnb.FeatureParameter(
            vecColor.x, vecColor.y, vecColor.z, vecColor.w);
        this._setColored();
        return this;
    }

    gloss(gloss) {
        this._gloss = new bnb.FeatureParameter(gloss, 0, 0, 0)
        this._setColored();
        return this;
    }

    textures(textures) {
        bnb.scene.enableRecognizerFeature(bnb.FeatureID.TEX_NAILS);
        this._entity.setActive(true);

        const nails = this._entity.getChildren();
        for (let i = 0; i < this._textures.length; i++) {
            if(textures.length > i) {
                this._textures[i].load(textures[i]);    
                nails[i].setActive(true);
            }
            else {
                this._textures[i].load("");
                nails[i].setActive(false);
            }
            
        }
        return this;
    }
    
    /** Resets any settings applied */
    clear() {
        this.color("0 0 0 0");
        this.gloss(defaultGloss);
        this.textures([]);
        this._entity.setActive(false);

        bnb.scene.disableRecognizerFeature(bnb.FeatureID.TEX_NAILS);
        bnb.scene.disableRecognizerFeature(bnb.FeatureID.NAILS);

    }

    _getMaterial(name) {
        const assets = bnb.scene.getAssetManager();
        const material = assets.findMaterial(name);
        if (!material) {
          bnb.log(`[WARN] Unable to find material "${name}"`);
          return null;
        }
        return material;
    }

    _setColored() {
        bnb.scene.enableRecognizerFeature(bnb.FeatureID.NAILS);
        bnb.scene.addFeatureParam(bnb.FeatureID.NAILS, [this._color , this._gloss]);
    }
}

exports = {
    Nails
}
